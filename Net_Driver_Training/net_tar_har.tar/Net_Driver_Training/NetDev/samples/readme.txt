Sample Code

module - Linux Kernel Module

chrdev - char device driver (old way)

cdev-dyn - char device driver (new way)

dma    - sample dma code

serint - isr for serial port

pcidev - code for PCI device

netdev - Network device

sem    - kernel sync using semaphore

procfs - interaction with /proc

oops   - generate/analyze oops message 

