Presebtation Files

LinuxKernelSource.ppt - Kernel souce code directory structure
module.ppt	      - linux kernel module
driver.ppt            - introduction to linux device driver
chrdev.ppt            - character device driver(data struct/methods)
hwdev.ppt             - interfacing with h/w (I/O, Memory, Intr)
GenericDma.ppt        - kernel DMA functions

PCI Drivers.ppt       - PCI Device Driver
PCIeSW-CM.ppt         - PCI Express CS
ksync.ppt             - atomic lock, semaphore/spinlock
BH.ppt                - Bottom Half Processing (softirq)
net1.ppt              - Network subsystem (Layers)

net2.ppt              - Network driver (data struct/methods)
NAPI.pptx             - New API/Interrupt Mitigation
Netlink sockets.ppt   - Netlink socket
LKDebug.ppt           - Debuggung techniques
